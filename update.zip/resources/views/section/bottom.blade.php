    <!-- Page JavaScript Files-->
    <script src="{{ URL::asset('template/assets/js/jquery.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/jquery-1.12.4.min.js') }}"></script>
    <!--Popper JS-->
    <script src="{{ URL::asset('template/assets/js/popper.min.js') }}"></script>
    <!--Bootstrap-->
    <script src="{{ URL::asset('template/assets/js/bootstrap.min.js') }}"></script>
    <!--Sweet alert JS-->
    <script src="{{ URL::asset('template/assets/js/sweetalert.js') }}"></script>
    <!--Progressbar JS-->
    <script src="{{ URL::asset('template/assets/js/progressbar.min.js') }}"></script>
    <!--Flot.JS-->
    <script src="{{ URL::asset('template/assets/js/charts/jquery.flot.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/charts/jquery.flot.pie.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/charts/jquery.flot.categories.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/charts/jquery.flot.stack.min.js') }}"></script>
    <!--Chart JS-->
    <script src="{{ URL::asset('template/assets/js/charts/chart.min.js') }}"></script>
    <!--Chartist JS-->
    <script src="{{ URL::asset('template/assets/js/charts/chartist.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/charts/chartist-data.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/charts/demo.js') }}"></script>
    <!--Maps-->
    <script src="{{ URL::asset('template/assets/js/maps/jquery-jvectormap-2.0.2.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/maps/jquery-jvectormap-world-mill-en.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/maps/jvector-maps.js') }}"></script>
    <!--Bootstrap Calendar JS-->
    <script src="{{ URL::asset('template/assets/js/calendar/bootstrap_calendar.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/calendar/demo.js') }}"></script>

        <!--Full calendar-->
    <script src="{{ URL::asset('template/assets/css/fullcalendar-3.9.0/lib/moment.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/css/fullcalendar-3.9.0/fullcalendar.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/full-calendar.js') }}"></script>
    <!--Nice select-->
    <script src="{{ URL::asset('template/assets/js/jquery.nice-select.min.js') }}"></script>

    <!--Custom Js Script-->
    <script src="{{ URL::asset('template/assets/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ URL::asset('template/assets/js/dataTables.bootstrap4.min.js') }}"></script>

    <!--Custom Js Script-->
    <script src="{{ URL::asset('template/assets/js/custom.js') }}"></script>
    <script src="//cdn.datatables.net/buttons/1.6.4/js/dataTables.buttons.min.js"></script>
    <script src="//cdn.datatables.net/buttons/1.6.4/js/buttons.flash.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="//cdn.datatables.net/buttons/1.6.4/js/buttons.html5.min.js"></script>
    <script src="//cdn.datatables.net/buttons/1.6.4/js/buttons.print.min.js"></script>
    <script>
    $('.bulk-actions').niceSelect();
    </script>