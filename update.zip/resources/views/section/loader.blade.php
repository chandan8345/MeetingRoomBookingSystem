<div class="loader-wrapper">
        <div class="loader-circle">
            <div class="loader-wave"></div>
        </div>
</div>