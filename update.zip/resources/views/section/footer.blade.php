<div class="row mt-5 mb-4 footer">
                    <div class="col-sm-8">
                        <span>&copy; 2020 GLIL IT. All Rights Reserved <a class="text-theme" href="#"></a></span>
                    </div>
                    <div class="col-sm-4 text-right">
                        <a href="#" class="ml-2">Contact Us</a>
                        <a href="#" class="ml-2">Support</a>
                    </div>
                </div>