<div class="col-sm-3 pl-0 text-center header-logo">
               <div class="bg-theme mr-3 pt-3 pb-2 mb-0">
                    <h4 class="logo">                    <img class="text-center" src="{{ URL::asset('template/assets/img/logo.png') }}" width="60" height="30" alt=""><span class="small"></span></a></h4>
               </div>
</div>